import mysql.connector
from pymongo import MongoClient


# ---------------------------------------
# MySQL Connection
# ---------------------------------------

def connect_mysql():

    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="ecommerce_db"
    )

    print("MySQL connected successfully.")

    return connection


# ---------------------------------------
# MongoDB Connection
# ---------------------------------------

def connect_mongodb():

    client = MongoClient("mongodb://localhost:27017/")

    database = client["ecommerce_db"]

    print("MongoDB connected successfully.")

    return client, database


# ---------------------------------------
# Display Customers from MySQL
# ---------------------------------------

def get_customers(connection):

    cursor = connection.cursor()

    query = """
        SELECT customer_id, first_name, last_name, email
        FROM customers
        LIMIT 5
    """

    cursor.execute(query)

    customers = cursor.fetchall()

    print("\nCustomers from MySQL:")

    for customer in customers:
        print(customer)

    cursor.close()


# ---------------------------------------
# Display Products from MongoDB
# ---------------------------------------

def get_products(database):

    products = database["products"]

    results = products.find(
        {},
        {
            "_id": 0,
            "product_id": 1,
            "name": 1,
            "category": 1,
            "price": 1
        }
    ).limit(5)

    print("\nProducts from MongoDB:")

    for product in results:
        print(product)


# ---------------------------------------
# Integrated Order and Product Operation
# ---------------------------------------

def get_order_with_product(connection, database):

    cursor = connection.cursor()

    query = """
        SELECT order_id, customer_id, total_amount
        FROM orders
        LIMIT 1
    """

    cursor.execute(query)

    order = cursor.fetchone()

    if order is None:
        print("No orders found.")
        cursor.close()
        return

    order_id = order[0]
    customer_id = order[1]
    total_amount = order[2]

    print("\nOrder from MySQL:")
    print("Order ID:", order_id)
    print("Customer ID:", customer_id)
    print("Total Amount:", total_amount)

    product = database["products"].find_one(
        {"product_id": 1001},
        {
            "_id": 0,
            "product_id": 1,
            "name": 1,
            "category": 1,
            "price": 1
        }
    )

    print("\nRelated Product from MongoDB:")

    if product:
        print(product)
    else:
        print("Product not found.")

    cursor.close()


# ---------------------------------------
# Main Application
# ---------------------------------------

def main():

    mysql_connection = None
    mongodb_client = None

    try:


        mysql_connection = connect_mysql()

        mongodb_client, mongodb_database = connect_mongodb()


        get_customers(mysql_connection)

        get_products(mongodb_database)

        get_order_with_product(
            mysql_connection,
            mongodb_database
        )

    except Exception as error:

        print("\nError:", error)

    finally:

        if mysql_connection:
            mysql_connection.close()
            print("\nMySQL connection closed.")

        if mongodb_client:
            mongodb_client.close()
            print("MongoDB connection closed.")


# Run application

if __name__ == "__main__":
    main()