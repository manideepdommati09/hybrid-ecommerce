-- Basic CRUD Queries
SELECT *
FROM customers;

SELECT *
FROM orders
WHERE total_amount > 100;

UPDATE orders
SET order_status = 'Delivered'
WHERE order_id = 2;

DELETE FROM payments
WHERE order_id = 5;

-- JOIN Query
SELECT
    c.first_name,
    c.last_name,
    o.order_id,
    o.order_date,
    o.order_status,
    o.total_amount
FROM customers c
JOIN orders o
ON c.customer_id = o.customer_id;

-- Aggregation Query
SELECT
    customer_id,
    COUNT(order_id) AS total_orders,
    SUM(total_amount) AS total_spending
FROM orders
GROUP BY customer_id;

-- Add Indexes
CREATE INDEX idx_order_customer
ON orders(customer_id);

CREATE INDEX idx_order_date
ON orders(order_date);

CREATE INDEX idx_payment_status
ON payments(payment_status);


-- Check the Indexes
SHOW INDEX FROM customers;

SHOW INDEX FROM orders;

SHOW INDEX FROM payments;


-- Test Query Performance
EXPLAIN
SELECT *
FROM orders
WHERE customer_id = 2;







































