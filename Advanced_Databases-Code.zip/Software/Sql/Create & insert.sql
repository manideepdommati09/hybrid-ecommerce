CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    address VARCHAR(150),
    registration_date DATE
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    order_status VARCHAR(30) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);

CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    payment_method VARCHAR(30) NOT NULL,
    payment_date DATE,
    amount DECIMAL(10,2) NOT NULL,
    payment_status VARCHAR(30) NOT NULL,

    FOREIGN KEY (order_id)
        REFERENCES orders(order_id)
);

CREATE TABLE inventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    warehouse_location VARCHAR(50),
    last_updated DATE
);


INSERT INTO customers
(first_name, last_name, email, phone, address, registration_date)
VALUES
('John', 'Smith', 'john.smith@email.com', '07111111111',
 'London', '2026-01-10'),

('Emma', 'Brown', 'emma.brown@email.com', '07222222222',
 'Manchester', '2026-01-15'),

('Oliver', 'Wilson', 'oliver.wilson@email.com', '07333333333',
 'Birmingham', '2026-02-01'),

('Sophia', 'Taylor', 'sophia.taylor@email.com', '07444444444',
 'Leeds', '2026-02-10'),

('James', 'Davies', 'james.davies@email.com', '07555555555',
 'Liverpool', '2026-02-20');
 
 
 INSERT INTO orders
(customer_id, order_date, order_status, total_amount)
VALUES
(1, '2026-03-01', 'Delivered', 149.99),

(2, '2026-03-02', 'Processing', 89.50),

(3, '2026-03-03', 'Shipped', 249.99),

(4, '2026-03-04', 'Delivered', 59.99),

(5, '2026-03-05', 'Processing', 199.00);


INSERT INTO payments
(order_id, payment_method, payment_date, amount, payment_status)
VALUES
(1, 'Credit Card', '2026-03-01', 149.99, 'Completed'),

(2, 'PayPal', '2026-03-02', 89.50, 'Completed'),

(3, 'Debit Card', '2026-03-03', 249.99, 'Completed'),

(4, 'Credit Card', '2026-03-04', 59.99, 'Completed'),

(5, 'PayPal', '2026-03-05', 199.00, 'Pending');

INSERT INTO inventory
(product_id, quantity, warehouse_location, last_updated)
VALUES
(1001, 50, 'London Warehouse', '2026-03-01'),

(1002, 75, 'Manchester Warehouse', '2026-03-02'),

(1003, 30, 'Birmingham Warehouse', '2026-03-03'),

(1004, 100, 'Leeds Warehouse', '2026-03-04'),

(1005, 45, 'Liverpool Warehouse', '2026-03-05');